package com.rocketseat.planner.activity;

public record ActivityRequestPayLoad(String title, String occurs_at) {
}
