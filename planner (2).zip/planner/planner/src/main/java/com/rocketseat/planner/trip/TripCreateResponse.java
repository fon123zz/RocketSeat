package com.rocketseat.planner.trip;

import java.util.UUID;

public record TripCreateResponse(UUID tripId) {
}
