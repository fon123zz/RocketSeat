package com.rocketseat.planner.participant;

public record ParticipantRequesPayLoad(String name,String email) {
}
