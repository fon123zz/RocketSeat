package com.rocketseat.planner.trip;

import java.util.List;
import java.util.UUID;

public class ParticipantService {
    public void registerParticipantsToEvent(List<String> strings, Trip newtrip) {
    }

    public void triggerConfirmationEmailToParticipants(UUID id) {

    }
}
