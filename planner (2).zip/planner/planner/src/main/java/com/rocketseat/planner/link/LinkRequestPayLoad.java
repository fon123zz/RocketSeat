package com.rocketseat.planner.link;

public record LinkRequestPayLoad(String title,String url) {
}
