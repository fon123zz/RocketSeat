package com.rocketseat.planner.activity;

import java.util.UUID;

public record ActivityResponse(UUID activityId) {
}
